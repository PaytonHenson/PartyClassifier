//
//  Cond.cpp
//  ML
//
//  Created by Payton Henson on 12/6/17.
//  Copyright © 2017 Payton Henson. All rights reserved.
//

#include "Cond.hpp"

Cond::Cond(int i, char v) {
    issue = i;
    vote = v;
}
